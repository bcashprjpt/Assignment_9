from django.shortcuts import render, redirect
from forms_app.forms import UserDetailForm
# Create your views here.

def index1(request):
    con = UserDetailForm()
    return render(request,'index1.html', {'form': con})


def index2(request):
    con = UserDetailForm()
    return render(request,'index2.html', {'form': con})


def user_info(request):
    form = UserDetailForm()
    if request.method == "POST":
        form = UserDetailForm(request.POST)
        if form.is_valid():
            first_name = form.cleaned_data['first_name']
            last_name = form.cleaned_data['last_name']
            email = form.cleaned_data['email']
            address = form.cleaned_data['address']


            request.session['first_name'] = first_name
            request.session['last_name'] = last_name
            request.session['email'] = email
            request.session['address'] = address
            return redirect('display')

    return render(request, 'index1.html', {'form': form})





def display_info(request):
    first_name = request.session.get('first_name')
    last_name = request.session.get('last_name')
    email = request.session.get('email')
    address = request.session.get('address')
    return render(request, 'display_user_info.html', {
        'first_name': first_name,
        'last_name': last_name,
        'email': email,
        'address': address
    })
