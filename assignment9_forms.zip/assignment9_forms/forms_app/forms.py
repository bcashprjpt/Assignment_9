from forms_app.models import UserDetail
from django import forms
class UserDetailForm(forms.ModelForm):
    class Meta:
        model= UserDetail
        fields = [
            'first_name',
            'last_name',
            'email',
            'address',
           ]