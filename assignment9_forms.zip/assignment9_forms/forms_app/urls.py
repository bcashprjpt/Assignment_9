
from django.urls import path
from forms_app import views

urlpatterns = [
   path('', views.user_info, name='index1'),
   path('target_url/',views.index2, name='index2'),
   path('display/', views.display_info, name='display'),
]

